create function update_total_price() returns trigger
    language plpgsql
as
$$
declare
        f_visitor_email varchar(50);
        f_time time;
        f_date date;
        f_sum integer;
        temp_price integer;
        ticket ticket_list%rowtype;
    begin
        f_visitor_email := new.visitor_email;
        f_time := new.time;
        f_date := new.date;

        f_sum := 0;
        for ticket in
                select *
                from ticket_list tl
                where tl.visitor_email = f_visitor_email
                  and tl.transaction_time = f_time
                  and tl.transaction_date = f_date
            loop
            select rate into temp_price
            from ticket_class tc
            where tc.event_id = ticket.event_id and tc.class_name = ticket.class_name;

            f_sum := f_sum + temp_price;
            end loop;

        new.total_price := f_sum;
        return new;
    end;
$$;

alter function update_total_price() owner to msoobvwvovwzyi;

