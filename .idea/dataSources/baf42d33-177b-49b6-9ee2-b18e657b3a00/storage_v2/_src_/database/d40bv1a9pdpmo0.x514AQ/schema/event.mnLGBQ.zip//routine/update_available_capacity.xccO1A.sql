create function update_available_capacity() returns trigger
    language plpgsql
as
$$
declare
        f_visitor_email varchar(50);
        f_time time;
        f_date date;
        f_event_id varchar(10);
        f_class_name varchar(10);
        f_transaction transaction%rowtype;
    begin
        if(tg_op = 'INSERT' or tg_op = 'UPDATE') then
            f_visitor_email := new.visitor_email;
            f_time := new.transaction_time;
            f_date := new.transaction_date;
            f_event_id := new.event_id;
            f_class_name := new.class_name;
        else
            f_visitor_email := old.visitor_email;
            f_time := old.transaction_time;
            f_date := old.transaction_date;
            f_event_id := old.event_id;
            f_class_name := old.class_name;
        end if;

        select * into f_transaction
        from transaction
        where status = 'Paid off'
          and visitor_email = f_visitor_email
          and time = f_time
          and date = f_date;

        if(FOUND) then
            update ticket_class
            set available_capacity = available_capacity - 1
            where event_id = f_event_id and class_name = f_class_name;
        end if;

        if(tg_op = 'INSERT' or tg_op = 'UPDATE') then
            return new;
        else
            return old;
        end if;
    end;
$$;

alter function update_available_capacity() owner to msoobvwvovwzyi;

