create function update_total_capacity() returns trigger
    language plpgsql
as
$$
declare
        found_total_capacity integer;
        found_total_available_capacity integer;
    begin
        if(tg_op = 'INSERT' or tg_op = 'UPDATE') then
            select sum(tc.capacity) into found_total_capacity
            from ticket_class tc
            where tc.event_id = new.event_id
            group by tc.event_id;

            select sum(tc.available_capacity) into found_total_available_capacity
            from ticket_class tc
            where tc.event_id = new.event_id
            group by tc.event_id;

            update event
            set total_capacity = found_total_capacity ,
            total_available_capacity = found_total_available_capacity
            where event_id = new.event_id;
        else
            select sum(tc.capacity) into found_total_capacity
            from ticket_class tc
            where tc.event_id = old.event_id
            group by tc.event_id;

            select sum(tc.available_capacity) into found_total_available_capacity
            from ticket_class tc
            where tc.event_id = old.event_id
            group by tc.event_id;

            update event
            set total_capacity = found_total_capacity, 
            total_available_capacity = found_total_available_capacity
            where event_id = old.event_id;
        end if;
return new;
    end;
$$;

alter function update_total_capacity() owner to msoobvwvovwzyi;

