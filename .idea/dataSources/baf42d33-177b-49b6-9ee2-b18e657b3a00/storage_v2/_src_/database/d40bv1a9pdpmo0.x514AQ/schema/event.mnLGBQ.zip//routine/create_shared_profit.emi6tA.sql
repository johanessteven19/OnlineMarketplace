create function create_shared_profit() returns trigger
    language plpgsql
as
$$
declare
        uuid varchar(20);
        commission integer;
        total_price integer;
        f_shared_profit shared_profit%rowtype;
    begin
        if(tg_op = 'INSERT') then
            if(new.status = 'Paid Off') then
                total_price := new.total_price;
                if(total_price > 1000000) then
                    commission := total_price * 0.05;
                else
                    commission := total_price * 0.02;
                end if;

                perform generate_uid(20) into uuid;
                insert into shared_profit (id, nominal) values (uuid, commission);
            end if;
        else
            select * into f_shared_profit
            from shared_profit
            where id = new.shared_profit_id;

            if(FOUND) then
                uuid := f_shared_profit.id;

                total_price := new.total_price;
                if(total_price > 1000000) then
                    commission := total_price * 0.05;
                else
                    commission := total_price * 0.02;
                end if;

                update shared_profit
                set nominal = commission
                where id = uuid;
            else
                perform generate_uid(20) into uuid;
                insert into shared_profit (id, nominal) values (uuid, commission);
            end if;
        end if;

        return new;
    end;
$$;

alter function create_shared_profit() owner to msoobvwvovwzyi;

