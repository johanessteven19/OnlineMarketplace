create function check_unique_email() returns trigger
    language plpgsql
as
$$
declare
        found_user "user"%rowtype;
    begin
        select * into found_user
        from "user" u
        where u.email = new.email;

        if(FOUND) then
            raise exception 'Email is not Unique';
        end if;

        return new;
    end;
$$;

alter function check_unique_email() owner to msoobvwvovwzyi;

