create function check_balance() returns trigger
    language plpgsql
as
$$
DECLARE
    e_balance real;
    BEGIN
        SELECT balance INTO e_balance
        FROM E_WALLET E
        WHERE new.e_wallet_no = E.account_no;

        IF(NEW.total_price > e_balance) THEN
            RAISE NOTICE 'Your E-wallet balance is insufficient. Payment put on hold.';
            NEW.status := 'Unpaid';

        else
            RAISE NOTICE 'Payment successful.';
            NEW.status := 'Paid off';

            UPDATE E_WALLET E
            SET balance = balance - NEW.total_price
            WHERE NEW.e_wallet_no = E.account_no;
        END IF;

        RETURN NEW;
    END;
$$;

alter function check_balance() owner to msoobvwvovwzyi;

